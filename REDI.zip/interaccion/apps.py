from django.apps import AppConfig


class InteraccionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'interaccion'
