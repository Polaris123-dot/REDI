"""
URL configuration for redima project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('usuarios/', include('usuarios.urls')),
    path('catalogacion/', include('catalogacion.urls')),
    path('proyectos/', include('proyectos.urls')),
    path('repositorio/', include('repositorio.urls')),
    path('publicaciones/', include('publicaciones.urls')),
    path('interaccion/', include('interaccion.urls')),
    path('notificaciones/', include('notificaciones.urls')),
    path('configuracion/', include('configuracion.urls')),
    path('metadatos/', include('metadatos.urls')),
    path('estadisticas/', include('estadisticas.urls')),
    path('busqueda/', include('busqueda.urls')),
    path('revisiones/', include('revisiones.urls')),
    # URLs públicas (sin autenticación)
    path('', include('catalogo_publico.urls')),
]

# Servir archivos de media en desarrollo
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
